To play the game, double click "Gruniożerca Meta.exe" file,
set the resolution and other settings as you please and hit "Play!"