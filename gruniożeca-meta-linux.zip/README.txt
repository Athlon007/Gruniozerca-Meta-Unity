To run this, simply double click the "Gruniożerca Meta.x86", or open terminal, navigate to the unpacked archive directory and type "./Gruniożeca Meta.x86" and hit enter.

WARNING: 
For some reason, the fullscreen mode doesn't work at all (well at least on my Linux machine). So that's why the game runs in windowed mode.